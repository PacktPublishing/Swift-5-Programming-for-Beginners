import Foundation

var age = 30
var wallet = 0
print(wallet)
wallet = 40
print(wallet)
wallet = 35

wallet

print(wallet)

print(123)
print("hello there!")

// Create a var that holds your lucky number and print it out
var lucky = 82
print(lucky)

